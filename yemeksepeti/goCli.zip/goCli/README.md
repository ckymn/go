welcome to my todo cli project 

when we start this project first thing we need to do

1 -> this project may do add , get, delete, find

2 -> if you want to create item 
    * firstly go build 
    * ./todo a -id "3" -item "Mami" -date "yesterday" -status "true"

3 -> if you want to give help 
    * fistly go build
    * ./todo get -h 

4 -> if you want to give project version
    * firstly go build 
    * ./todo get -v

5 -> if you want to give list all items (un-completed)
    * firstly go build
    * ./todo get -l

6 -> if you want to give list completed items
    * firstly go build
    * ./todo get -c

7 -> if you want to change mark as complete
    * firstly go build
    * ./todo add -m <TODO-ID>

8 -> if you want to delete item
    * firtsly go build
    * ./todo add -d <TODO-ID>
